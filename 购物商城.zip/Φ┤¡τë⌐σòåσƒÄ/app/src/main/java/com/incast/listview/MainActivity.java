package com.incast.listview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.incast.listview.R;

public class MainActivity extends AppCompatActivity {


    private String[] titles = { "桌子", "苹果", "蛋糕", "线衣", "猕猴桃",
            "围巾"};
    private String[] prices = { "1800元", "10元/kg", "300元", "350元", "10元/kg",
            "280元"};
    //图片集合
    private int[] icons = {R.drawable.table,R.drawable.apple,R.drawable.cake,
            R.drawable.wireclothes,R.drawable.kiwifruit,R.drawable.scarf};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "哈哈哈哈哈哈哈哈哈哈哈哈", Toast.LENGTH_SHORT).show();

        ListView lv = findViewById(R.id.lv);//通过id获取ListView
        lv.setAdapter(new MyBaseAdapter());//给ListView设置数据适配器
    }

    //定义内部类
    class MyBaseAdapter extends BaseAdapter
    {

        @Override
        public int getCount() {//返回子元素的个数
            return titles.length;
        }

        @Override
        public Object getItem(int position) {//返回指定位置的子元素
            return null;
        }

        @Override
        public long getItemId(int position) {//返回子元素的ID
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {//基于模板生成每个子元素
            View view = View.inflate(MainActivity.this,R.layout.list_item,null);
            ImageView iv = view.findViewById(R.id.iv);
            TextView title = view.findViewById(R.id.title);
            TextView price = view.findViewById(R.id.price);
            iv.setBackgroundResource(icons[position]);
            title.setText(titles[position]);
            price.setText(prices[position]);
            return view;
        }
    }
}
