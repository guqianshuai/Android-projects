package com.incast.myapplication;
import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private TextView tv_show;
    private Button bt_show;
    private List<Sms> list=new ArrayList<>();
    private String text="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_show=findViewById(R.id.tv_show);
        bt_show=findViewById(R.id.bt_show);
    }

    public void show(View view) {
        ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.READ_SMS},1);
    }
    public void getSms(){
        Uri uri= Uri.parse("content://sms/");
        ContentResolver contentResolver=getContentResolver();
        Cursor cursor = contentResolver.query(uri, new String[]{"_id", "address",
                "body"}, null, null, null);
        if (cursor!=null&&cursor.getCount()>0){
            if (list!=null){
                list.clear();
            }
            text="";
            while (cursor.moveToNext()){
                int id=cursor.getInt(0);
                String name=cursor.getString(1);
                String body=cursor.getString(2);
                Sms sms=new Sms(id,name,body);
                list.add(sms);
            }
            for (int i=0;i<list.size();i++){
                text+="手机号码："+list.get(i).getAddress()+"\n";
                text+="短信内容："+list.get(i).getBody()+"\n\n";
            }
            tv_show.setText(text);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode==1){
            for (int i=0;i<permissions.length;i++){
                if (grantResults[i]== PackageManager.PERMISSION_GRANTED){
                    getSms();
                }else {
                    Toast.makeText(MainActivity.this,"无权限",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


}
