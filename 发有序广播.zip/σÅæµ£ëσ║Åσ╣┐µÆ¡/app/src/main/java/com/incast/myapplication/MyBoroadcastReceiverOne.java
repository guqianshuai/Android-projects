package com.incast.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBoroadcastReceiverOne extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent){
        Log.i("MyBoroadcastReceiverOne","定义的接收者One,收到了广播事件");
    }
}
