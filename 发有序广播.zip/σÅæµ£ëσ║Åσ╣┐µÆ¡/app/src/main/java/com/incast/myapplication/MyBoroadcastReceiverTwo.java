package com.incast.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBoroadcastReceiverTwo extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent){
        Log.i("MyBoroadcastReceiverTwo","定义的接收者Two,收到了广播事件");
        abortBroadcast();
        Log.i("BoroadcastReceiverTwo","我是广播接收Two,广播被我拦截了");
    }
}
