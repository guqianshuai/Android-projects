package com.incast.myapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class MyBoroadcastReceiverThree extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent){
        Log.i("MyBoroadcastReceiverThree","定义的接收者Three,收到了广播事件");
    }
}
